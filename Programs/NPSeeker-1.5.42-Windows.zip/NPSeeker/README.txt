
╔══__   _  ____  ____  ____  ____  _  _  ____  ____════════════════════════════╗
║ |  \ | ||  _ \/ ___||  __||  __|| |/ /|  __||  _ \ Nucleic acid Probe Seeker ║
║ |   \| || |_) \_   \|  __)|  __)|   / |  __)| |_) | v.1.5.42, build 20261010 ║
║ | |\   ||  __/ __)  | (__ | (__ |   \ | (__ |    /                           ║
║ |_| \__||_|   |____/|____||____||_|\_\|____||_|\_\    10Lab, NYCU, Taiwan    ║
║------------------------------------------------------------------------------║
║ An efficient nucleic acid probe design algorithm for biochips.               ║
║ For more information, visit https://10lab.ceb.nycu.edu.tw/                   ║
╚══════════════════════════════════════════════════════════════════════════════╝


=========================
 Overview
=========================

NPSeeker is a genome-driven nucleic acid probe design program for species
identification and group classification using BioFETs and other biochip
platforms.

Given target genomes (from organisms to be detected) and control genomes (from
organisms that should not be detected), NPSeeker identifies DNA sequences shared
by the targets, or within target clusters when necessary. It then ranks
candidate probes using four scores: exclusivity, purity, unfoldability, and
affinity. NPSeeker provides both a command-line interface and a browser-based
graphical interface.


=========================
 Package contents
=========================

  bin/            NPSeeker for x86_64 processors (most Intel and AMD)
  bin.arm64/      NPSeeker for arm64 processors (such as Apple M-series)
  doc/            User manuals in several languages
  dat/sample/     Example data for a first run

The bacterial genomes used in the NPSeeker paper are a separate download
(NPSeeker-1.5.42-datasets.zip or .tar.gz). You may extract it and move the
datasets folder it contains (under NPSeeker/dat/) into the dat folder of this
package, so that you can run the command examples in the user manual as written.


=========================
 Requirements
=========================

64-bit Windows, macOS, or Linux. NPSeeker requires no installation or additional
analysis software. Its graphical interface runs in a web browser.


=========================
 Quick start
=========================

Extract the archive and run the commands below in the extracted folder
(Section 0.3 of the user manual shows how to open a command window there). On
an arm64 computer, use bin.arm64 in place of bin.

The first time you run NPSeeker, the system may warn you because the program
is not signed. If you downloaded it from the NPSeeker website or GitHub page:

  Windows        Click "More info", then "Run anyway".
  macOS          In Terminal, run xattr -dr com.apple.quarantine followed by
                 the path of the NPSeeker folder.
  Linux          If you see "permission denied", run chmod +x bin/npseeker.

Graphical interface:

  Windows        Double-click npseeker.exe in the bin folder.
  macOS, Linux   Run ./bin/npseeker --gui in a terminal.

On the Design page, select dat/sample/S.aureus/ as Target and dat/sample/yeast/
as Control, then click "Check" and "Go". The results appear on the Results
page.

Command line:

    Windows:          .\bin\npseeker.exe dat\sample\S.aureus\ dat\sample\yeast\
    macOS, Linux:     ./bin/npseeker     dat/sample/S.aureus/ dat/sample/yeast/

The first folder holds the target genome (Staphylococcus aureus) and the second
holds the control genomes (two yeasts). The top-ranked probes are displayed on
the screen; add -o result/ to save detailed results to files.


=========================
 Documentation
=========================

The user manual, in several languages, is in the doc folder. Open the .html file
in a web browser, or the .txt file in doc/txt/ in a text editor. The graphical
interface also shows the manual on its Help page.

Built-in help:

    ./bin/npseeker -h               Common options
    ./bin/npseeker -help            All options
    ./bin/npseeker -help -mode      Help for one option (here, -mode)


=========================
 Downloads and datasets
=========================

The latest NPSeeker release and the datasets used for benchmarking in the
NPSeeker study are available from the project GitHub page:

  https://github.com/NYCU-10lab/NPSeeker/

More information is on the NPSeeker website:

  https://10lab.ceb.nycu.edu.tw/NPSeeker/

Chapter 8 of the user manual shows how to use dat/datasets/ to reproduce the
bacterial probes in Table 3 of the paper.


=========================
 Citation
=========================

If you use NPSeeker in your research, please cite:

  Hao-Yu Peng, Hui Zhi Gan, et al. NPSeeker: A BioFET-oriented Nucleic Acid
  Probe Design Algorithm for Efficient Species Identification and
  Classification.


=========================
 License
=========================

NPSeeker is distributed under the NPSeeker Executable Software License. See
LICENSE.txt for the terms governing its use and redistribution.


=========================
 Contact information
=========================

Software authors:

  Wei-Cheng Lo (羅惟正)
  Hao-Yu Peng  (彭浩宇)
  Hui Zhi Gan  (顏慧芝)

NPSeeker is maintained by 10Lab,
Institute of Bioinformatics and Systems Biology,
National Yang Ming Chiao Tung University,
Hsinchu, Taiwan.

For questions, bug reports, or feedback, please contact:

  WadeLo@nycu.edu.tw

When reporting a problem, please include the NPSeeker version (shown by
./bin/npseeker -h), your operating system, the command or settings you used,
and the error message.

